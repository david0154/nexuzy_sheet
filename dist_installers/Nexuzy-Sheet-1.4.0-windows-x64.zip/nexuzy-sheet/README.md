# Nexuzy Sheet

**Nexuzy Sheet** is a free, open source spreadsheet workspace for Windows,
macOS and Linux. It combines an Excel-like interface with Python powered
cells, 110 spreadsheet functions, business templates, charts and local AI
assistance.

Developed by **Nexuzy Lab** — <https://nexuzy.in>

* **License:** MIT — free and open source, free to use forever
* **Native workbook format:** `.nix`
* **Languages:** English, हिन्दी, বাংলা, தமிழ், Español, Français, 中文,
  Русский, 日本語
* **Platforms:** Windows, macOS, Linux (desktop application)

---

## Contents

1. [Highlights](#highlights)
2. [Screens at a glance](#screens-at-a-glance)
3. [Install](#install)
4. [Run from source](#run-from-source)
5. [Workbook format, auto save and backups](#workbook-format-auto-save-and-backups)
6. [Languages](#languages)
7. [Spreadsheet functions](#spreadsheet-functions)
8. [Import and export](#import-and-export)
9. [Templates](#templates)
10. [Build installers for all platforms](#build-installers-for-all-platforms)
11. [Project layout](#project-layout)
12. [Documentation](#documentation)
13. [Feature status](#feature-status)
14. [License](#license)
15. [Support](#support)

---

## Highlights

* **Excel-like grid** with menus, dockable toolbars, entry line, table tabs,
  status bar statistics, dark and light themes, full screen and 18 zoom levels.
* **Python cells** – every cell is an expression, so `SUM(S[0:10, 2, 0])`,
  `IF(...)`, `VLOOKUP(...)` or any Python code works directly.
* **110 spreadsheet functions** across mathematical, statistical, logical,
  lookup, text, date, financial and information categories.
* **Business templates** – invoice, attendance register, general ledger,
  payroll sheet and budget planning.
* **Charts and images** inside cells through matplotlib and SVG.
* **`.nix` workbooks** – compressed, self contained, holds code, formatting,
  macros, images and charts.
* **Auto save** recovery copies every two minutes while there are unsaved
  changes, plus **automatic backups** and a **version history** dialog.
* **AutoFit** – column widths and row heights adapt to the cell content
  (`Format → AutoFit columns / AutoFit rows / AutoFit selection`).
* **Offline AI assistant** – Qwen2.5-0.5B-Instruct (about 490 MB) is fetched
  once on the first start and then runs locally in the AI panel.
* **Nine interface languages** with live switching in `View → Language`.
* **Installer build system** for Windows, macOS and Linux with `.nix` file
  association on every platform.
* **MIT licensed**, free forever, no account and no subscription.

## Screens at a glance

| Area | What it does |
| --- | --- |
| Menu bar | File, Edit, View, Format, Macro, Help |
| Toolbars | Main, Format, Find, Macro — all dockable and hideable |
| Entry line | Formula and value editor of the current cell |
| Grid | The spreadsheet with four synchronised views |
| Table tabs | The worksheets of the workbook |
| Macro panel | Python code that is stored inside the workbook |
| Status bar | Sum, average, count, min, max, zoom state, safe mode |

## Install

Download the installer for your platform from the release page:

| Platform | Artifact | Installer |
| --- | --- | --- |
| Windows x64 | `Nexuzy-Sheet-<version>-windows-x64-setup.exe` | Inno Setup, optional `.nix` association |
| Windows x64 (portable) | `Nexuzy-Sheet-<version>-windows-x64.zip` | unpack and run `nexuzy-sheet.exe` |
| macOS | `Nexuzy-Sheet-<version>-macos.dmg` | drag into *Applications* |
| Linux | `Nexuzy-Sheet-<version>-linux-x86_64.AppImage` | `chmod +x` and run |
| Debian/Ubuntu | `Nexuzy-Sheet-<version>-linux-amd64.deb` | `sudo dpkg -i …` |
| Linux (portable) | `Nexuzy-Sheet-<version>-linux-x86_64.tar.gz` | unpack and run |

All installers are generated from this repository with
[`build_installers.py`](build_installers.py); see
[Build installers](#build-installers-for-all-platforms).

## Run from source

Requirements: Python 3.8 or newer (tested with Python 3.14 on Windows) and a
desktop session.

```bash
git clone https://github.com/david0154/nexuzy-sheet.git
cd nexuzy-sheet

python -m venv .venv
# Windows PowerShell
.\.venv\Scripts\Activate.ps1
# Linux / macOS
source .venv/bin/activate

python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python -m nxsheet
```

Optional extras:

```bash
python -m pip install -r nxsheet/optional_ai_requirements.txt   # AI/OCR
python -m pip install openpyxl xlwt odfpy                       # XLSX/XLS/ODS support
```

Open a workbook from the command line:

```bash
python -m nxsheet "C:/Work/Report.nix"
```

## Workbook format, auto save and backups

Nexuzy Sheet saves workbooks as **`.nix`** by default. The format stores cell
code, formatting, row heights, column widths, macros, images and charts,
compressed with bzip2. `.nxl` (uncompressed) and `.nxs` (compressed) from older
builds are still read and can still be written.

| Safety feature | Behaviour |
| --- | --- |
| Auto save | Recovery copy every 120 s while there are unsaved changes → `~/.nexuzy_sheet/autosave` |
| Automatic backup | After every save → `~/.nexuzy_sheet/backups/<workbook>/`, newest 20 kept |
| Close protection | A final recovery copy is written when closing with unsaved changes |
| Version history | `File → Version history…` lists, restores and deletes recovery copies and backups |

`.nix` is a **compressed, not encrypted** container; see
[docs/FILE_FORMAT.md](docs/FILE_FORMAT.md) for the format description and the
reader/writer example.

## Languages

The interface language is switched live in `View → Language` and stored for
the next start:

| Code | Language | Native name |
| --- | --- | --- |
| `en` | English | English |
| `hi` | Hindi | हिन्दी |
| `bn` | Bengali | বাংলা |
| `ta` | Tamil | தமிழ் |
| `es` | Spanish | Español |
| `fr` | French | Français |
| `zh` | Chinese | 中文 |
| `ru` | Russian | Русский |
| `ja` | Japanese | 日本語 |

Translations live in [`nxsheet/i18n.py`](nxsheet/i18n.py) and cover the menus,
the common actions and the About dialog. A string that has no entry stays in
English, so a partially translated build is still fully usable. Adding a
language is one dictionary entry plus its 65 source strings.

## Spreadsheet functions

Functions are typed directly into cells and accept cell ranges, numpy arrays,
lists and generators:

```python
SUM(S[0:10, 0, 0])
AVERAGE(S[1:5, 2, 0])
IF(S[0, 0, 0] > 100, "high", "low")
VLOOKUP("Apple", S[0:20, 0:2, 0], 2, False)
TEXT(S[0, 1, 0], "#,##0.00")
PMT(0.05/12, 60, -10000)
```

`Shift+F3` opens the searchable function catalog with signatures. The full
list of 110 functions and the functions that are **not** implemented yet is in
[docs/FEATURES.md](docs/FEATURES.md).

## Import and export

| Format | Import | Export |
| --- | --- | --- |
| `.nix` (native) | ✅ | ✅ |
| `.nxl`, `.nxs` (legacy native) | ✅ | ✅ |
| XLSX | ✅ (`openpyxl`) | ✅ |
| XLS | — | ✅ (`xlwt`) |
| CSV | ✅ | ✅ |
| TSV | ✅ | ✅ |
| ODS | — | ✅ (`odfpy`) |
| PDF | — | ✅ |
| HTML | — | ✅ |
| JSON | — | ✅ |
| TXT | — | ✅ |
| SVG | — | ✅ |
| PNG / JPG (cell images and charts) | — | ✅ |

## Templates

Five ready-made business templates are built in
([`nxsheet/templates.py`](nxsheet/templates.py)):

* Invoice
* Attendance Register
* General Ledger
* Payroll Sheet
* Budget Planning

Each template brings headers, sample data, merged title areas, number columns
and a styling configuration.

## Offline AI assistant

Nexuzy Sheet ships with a local spreadsheet assistant based on
**Qwen2.5-0.5B-Instruct (GGUF, Q4_K_M, about 490 MB)**:

* On the first start the model is downloaded in the background into
  `~/.nexuzy_sheet/models/` — the window opens immediately and the status bar
  reports the progress and the result.
* After the first run the assistant works completely offline.
* If the download fails (no network, no space), the app keeps working with its
  built-in spreadsheet action engine; nothing breaks.
* The same model is used on Windows, macOS and Linux.

The AI panel can turn plain language into spreadsheet actions, fill templates
and read invoices, images and PDFs (OCR extras are optional). No account and
no API key are required and no spreadsheet data is uploaded by the local
model.

## Build installers for all platforms

The repository builds native installers for **Windows, macOS and Linux**. The
application is bundled with PyInstaller and wrapped in the platform's native
installer format.

```bash
python -m pip install -r requirements.txt pyinstaller
python build_installers.py                 # installer for the current platform
python build_installers.py --clean         # clean build
python build_installers.py --no-native     # portable archives only
```

| Platform | Artifacts produced |
| --- | --- |
| Windows | `dist/installers/Nexuzy-Sheet-<version>-windows-x64.zip`, `…-setup.exe` (Inno Setup 6, includes `.nix` association) |
| macOS | `dist/installers/Nexuzy-Sheet-<version>-macos.zip`, `…-macos.dmg` (`hdiutil`) |
| Linux | `dist/installers/Nexuzy-Sheet-<version>-linux-<arch>.tar.gz`, `.deb` (`dpkg-deb`, includes desktop entry + MIME type), `.AppImage` (`appimagetool`) |

PyInstaller cannot cross compile, so each platform must be built on its own
machine or in CI. The bundled workflow
[`.github/workflows/build-installers.yml`](.github/workflows/build-installers.yml)
builds all three platforms in parallel on `workflow_dispatch` and on `v*` tags
and uploads the artifacts:

```bash
git tag v1.2.0 && git push origin v1.2.0
```

Requirements for native packaging: Inno Setup 6 on Windows, `hdiutil` on
macOS, `dpkg-deb` and `appimagetool` on Linux. If a tool is missing the script
skips that artifact and still produces the portable archive.

## Project layout

```text
nxsheet/                     application source
├── main.py                  entry point
├── main_window.py           main window, docks, printing, language switching
├── menus.py                 menu bar, context menus, language menu
├── actions.py               all QActions
├── workflows.py             file, edit, import/export, printing workflows
├── autosave.py              auto save, automatic backups, version history
├── i18n.py                  nine language translation catalog
├── settings.py              persisted application settings
├── templates.py             business templates
├── dialogs.py               file, find, chart, print, about dialogs
├── grid.py / grid_renderer.py   the spreadsheet widget and renderer
├── model/model.py           code array, cell attributes, evaluation
├── lib/excel_functions.py   110 spreadsheet functions
├── interfaces/pys.py        native workbook reader and writer
├── interfaces/xlsx.py       XLSX import
├── ai/engine.py             local AI and document support
└── share/                   icons, examples, manual, tutorial
installers/                  PyInstaller spec, Inno Setup, DMG, AppImage, deb, MIME
build_installers.py          builds all platform installers
docs/                        user guide, feature audit, file format
```

## Documentation

* [docs/GUIDE.md](docs/GUIDE.md) — complete user guide
* [docs/FEATURES.md](docs/FEATURES.md) — verified feature status, including
  the features that are **not** implemented
* [docs/FILE_FORMAT.md](docs/FILE_FORMAT.md) — the `.nix` workbook format
* `nxsheet/share/doc/manual` and `nxsheet/share/doc/tutorial` — in-app help
  (`Help → Manual`, `Help → Tutorial`)
* Help → About shows version, platform, license, languages and support

## Feature status

Nexuzy Sheet 1.2.0 implements workbook and file management, cell editing,
formatting, the formula engine, sorting, importing/exporting, printing,
templates, charts, macros, auto save, backups and nine languages.

It is **not** a complete Excel clone. The following are not implemented in
this release and are listed with full detail in
[docs/FEATURES.md](docs/FEATURES.md): pivot tables, conditional formatting,
filtering, data validation, named ranges, comment threads, hyperlinks,
real-time collaboration, cloud sync, accounts and 2FA, password-protected
workbooks, a plugin system and a web/mobile build.

## License

Nexuzy Sheet is released under the **MIT License**. It is free and open source
and stays free to use forever.

Copyright (c) 2026 Nexuzy Lab. See [LICENSE](LICENSE) for the full text.
The optional local AI model download is a separate runtime component and is
subject to the upstream model license.

## Support

* Website: <https://nexuzy.in>
* Company: **Nexuzy Lab**
* Support e-mail: <support@nexuzy.in>
* Information e-mail: <info@nexuzy.in>
* Lead developer: David
* Issues: <https://github.com/david0154/nexuzy-sheet/issues>
